<style>
table td{
 border:1px solid;
}
</style>

								  
 <table class="table table-bordered">
	
	<tr>
	<td>
	 <label class="">First name:</label> 
	 <span id="idname">1</span>
	</td>
	
	<td>
	<label class="">Middle name:</label> 
	 <span>2</span>
	</td>

	<td>
	<label class="">Last name:</label> 
	 <span>3</span>
	</td>
	
	</tr>
 
 
	<tr>
	
	<td>
	<label class="">D.O.B:</label> 
	<span>3</span>
	</td>

	<td>
	<label class="">SSN:</label>
	<span>3</span>
	</td>
	
	<td>
	<label class="">Phone:</label>
	 <span>3</span>
	</td> 
	</tr>
	
 
 
    <tr>
	<td colspan="3">
	<label class="">Current address:</label>
	<span>3</span>
	</td>
	</tr>

						
	<tr>
	<td> 
	<label class="">CITY:</label>
	<span>99999</span>  
	</td>
	
	<td> 
	<label class="">STATE:</label>
	<span>Alabama</span> 
	</td>
	
	<td> 
	<label class="">ZIPCODE:</label>
	<span>1000000</span>
 	
	</td>
	</tr>
	 
 	<tr>
	<td colspan="3" class="p0"> 
	
	<table class="table table-bordered">
	<tr><td>
	<label class="">Own/Rent:</label>
	<span>Own</span>	
	</td>
	
	<td>
	<label class="">Monthly payment or rent:</label>
	<span>1001 -1500</span>	
	</td>
	
	<td>
	<label class="">How long?:</label>	
	<span>12-18 Months</span> 	
	</td>
	</tr>
	</table>
	
	</td>
	
	
 
  </tr><tr>
<td colspan="3">  
	<label class="">Previous address:</label>
	<span>1100000</span>
</td>
</tr>		
		
<tr> 
	<td> 
	<label class="">CITY:</label>
	<span>1200000</span> 
	</td>
	
	<td> 
	<label class="">STATE:</label>
	<span>Alabama</span>
	</td>	
	
	<td> 
	<label class="">ZIPCODE:</label>	
	<span>130000</span>
	</td> 
</tr>


<tr>
	<td>
    <label class="">Own/Rent:</label> 
	<span>Rent</span>
	</td>
	
	<td> 	 
	<label class="">Monthly payment or rent:</label>
	<span>1501 - 2000</span>
	</td>
</tr></table> 