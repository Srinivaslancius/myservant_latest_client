 <div class="container">
            <h3>Choose from over <?php echo getRowsCount('food_vendors'); ?> Restaurants</h3>
            <p></p>
            <a href="list.php">View all Restaurants</a>
        </div><!-- End container -->
     